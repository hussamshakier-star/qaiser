import { motion } from "motion/react";
import { useParams, Link } from "react-router-dom";
import { PORTFOLIO_DATA } from "../data";
import { ArrowLeft } from "lucide-react";

export default function BlogPost() {
  const { id } = useParams();
  const post = PORTFOLIO_DATA.blogPosts.find((p) => p.id === id);

  if (!post) {
    return (
      <div className="text-center py-20">
        <h1 className="text-3xl text-[#111] font-bold mb-4">Post not found</h1>
        <Link to="/blog" className="text-blue-600 hover:text-blue-800 font-medium underline underline-offset-4">
          Back to all posts
        </Link>
      </div>
    );
  }

  return (
    <motion.article
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="max-w-2xl mx-auto py-12"
    >
      <Link to="/blog" className="inline-flex items-center gap-2 text-[10px] font-bold text-gray-400 hover:text-[#111] transition-colors mb-12 tracking-widest uppercase">
        <ArrowLeft className="w-4 h-4" />
        BACK TO BLOG
      </Link>
      
      <header className="mb-14">
        <time className="text-[10px] font-bold uppercase tracking-widest text-gray-400 block mb-4">
          {post.date}
        </time>
        <h1 className="text-4xl md:text-5xl font-extrabold tracking-tight text-[#111] leading-tight">
          {post.title}
        </h1>
      </header>

      <div className="prose prose-lg prose-headings:font-bold prose-headings:tracking-tight prose-a:text-blue-600 hover:prose-a:text-blue-500 max-w-none text-gray-600 leading-relaxed">
        <p>{post.content}</p>
        
        {/* Mocking a longer post visually */}
        <p>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam nec efficitur turpis. In non ipsum metus. Vestibulum tristique sapien magna, et congue leo malesuada mattis. Nulla sit amet dui at urna lacinia lobortis in a enim.
        </p>

        <p>
           Aenean tristique dolor nisl, nec faucibus magna pretium vitae. Suspendisse eu odio vel erat dictum posuere sit amet eleifend turpis. Interdum et malesuada fames ac ante ipsum primis in faucibus.
        </p>
      </div>
    </motion.article>
  );
}
