import { motion } from "motion/react";
import { Link } from "react-router-dom";
import { PORTFOLIO_DATA } from "../data";

const textVariants = {
  hidden: { opacity: 0, y: 30 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.8, ease: [0.16, 1, 0.3, 1] } }
};

export default function Home() {
  return (
    <div className="w-full">
      {/* Main Hero Wrapper */}
      <section className="relative w-full min-h-[85vh] flex items-center pt-8 pb-20 justify-center">
        {/* Giant Background Text */}
        <motion.div 
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1.5, ease: "easeOut" }}
          className="absolute top-1/4 left-1/2 -translate-y-1/2 -translate-x-1/2 w-full overflow-hidden flex justify-center pointer-events-none select-none z-0"
        >
          <h1 className="text-[16vw] font-black text-gray-50 tracking-tighter uppercase whitespace-nowrap">
            accountant
          </h1>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 w-full z-10">
          {/* Left Content */}
          <motion.div 
            initial="hidden"
            animate="visible"
            variants={{
              visible: { transition: { staggerChildren: 0.15 } }
            }}
            className="flex flex-col justify-center pt-10"
          >
            <motion.p variants={textVariants} className="text-[10px] font-extrabold tracking-[0.2em] text-gray-400 uppercase mb-4">
              {PORTFOLIO_DATA.name}
            </motion.p>
            <motion.h2 variants={textVariants} className="text-5xl md:text-6xl lg:text-[4.5rem] font-extrabold leading-[1.05] tracking-tight mb-8 text-[#111]">
              Financial and corporate reporting <br/> expert
            </motion.h2>
            <motion.p variants={textVariants} className="text-gray-500 font-medium text-base md:text-lg max-w-lg leading-relaxed mb-10">
              {PORTFOLIO_DATA.about}
            </motion.p>
            <motion.div variants={textVariants} className="flex items-center text-sm font-bold tracking-wide">
              <a href="#projects" className="underline decoration-2 underline-offset-4 hover:text-gray-500 transition-colors cursor-pointer">View Projects</a>
              <span className="mx-4 text-xs font-serif italic text-gray-400">or</span>
              <Link to="/blog" className="font-bold hover:text-gray-500 transition-colors">Read About Me</Link>
            </motion.div>
            
            {/* Scroll Indicator */}
            <motion.div variants={textVariants} className="mt-20 w-6 h-10 border-2 border-gray-300 rounded-full flex justify-center p-1">
               <motion.div 
                 animate={{ y: [0, 12, 0] }}
                 transition={{ repeat: Infinity, duration: 1.5 }}
                 className="w-1 h-2 bg-gray-400 rounded-full"
               />
            </motion.div>
          </motion.div>

          {/* Right Image */}
          <motion.div 
            initial={{ opacity: 0, filter: "blur(10px)", scale: 0.95 }}
            animate={{ opacity: 1, filter: "blur(0px)", scale: 1 }}
            transition={{ duration: 1.2, delay: 0.3, ease: [0.16, 1, 0.3, 1] }}
            className="relative flex justify-center md:justify-end items-end h-full"
          >
             {/* Replace with a large cutout style photo later if qa.png is small */}
             <img 
              src="qa.png" 
              alt="Qaiser Ali Yass" 
              className="max-h-[70vh] md:max-h-[85vh] object-contain drop-shadow-2xl select-none" 
             />
          </motion.div>
        </div>
      </section>

      {/* Projects Section */}
      <section id="projects" className="py-24 w-full">
        <motion.div
           initial={{ opacity: 0, y: 20 }}
           whileInView={{ opacity: 1, y: 0 }}
           viewport={{ once: true }}
           className="mb-14 max-w-5xl"
        >
          <p className="text-[10px] font-extrabold tracking-[0.2em] text-gray-400 uppercase mb-4">Case Studies</p>
          <h2 className="text-4xl md:text-5xl font-extrabold tracking-tight text-[#111]">Selected projects</h2>
        </motion.div>

        <div className="flex overflow-x-auto gap-6 sm:gap-8 pb-12 snap-x snap-mandatory pt-4 -mx-6 px-6 lg:-mx-16 lg:px-16 [&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none]">
          {PORTFOLIO_DATA.projects.map((project, i) => (
            <motion.a
              href={project.link}
              key={project.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="group block relative bg-[#111] overflow-hidden min-h-[400px] sm:min-h-[500px] p-8 sm:p-10 flex flex-col justify-start hover:scale-[1.02] transition-transform duration-500 w-[85vw] sm:w-[400px] md:w-[450px] flex-none snap-start"
            >
              <div className="relative z-10 mb-8">
                <p className="text-gray-400 text-xs font-bold tracking-widest mb-4 uppercase">
                   2024 &mdash; 2026
                </p>
                <h3 className="text-2xl font-bold text-white mb-4 leading-tight">
                  {project.title.split(' ')[0]} <span className="text-gray-400">&mdash; {project.title.split(' ').slice(1).join(' ')}</span>
                </h3>
              </div>

              {project.imageUrl && (
                <div className="absolute bottom-[-10%] right-[-10%] w-[120%] h-[80%] z-0 origin-bottom-right group-hover:scale-105 transition-transform duration-700">
                  <div className="absolute inset-0 bg-gradient-to-t from-[#111]/90 via-[#111]/20 to-transparent z-10" />
                  <img 
                    src={project.imageUrl}
                    alt=""
                    className="w-full h-full object-cover opacity-60 block"
                    referrerPolicy="no-referrer"
                  />
                </div>
              )}

              <div className="relative z-10 mt-auto flex flex-wrap gap-2 pt-8">
                {/* Visual badge inside the card similar to the reference graphic */}
                <div className="bg-[#1a1a1a] text-white px-4 py-3 border border-white/10 text-xs font-medium w-full flex flex-col gap-1 rounded-sm shadow-xl">
                    <span className="text-gray-500 text-[10px] uppercase font-bold tracking-wider">Expertise applied</span>
                    <span className="leading-relaxed">{project.tech.join(', ')}</span>
                </div>
              </div>
            </motion.a>
          ))}
        </div>
      </section>
    </div>
  );
}
