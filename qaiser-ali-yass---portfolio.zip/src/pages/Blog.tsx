import { motion } from "motion/react";
import { Link } from "react-router-dom";
import { PORTFOLIO_DATA } from "../data";
import { ArrowRight } from "lucide-react";

export default function Blog() {
  return (
    <div className="max-w-3xl py-12">
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <p className="text-[10px] font-extrabold tracking-[0.2em] text-gray-400 uppercase mb-4">Blog & Thoughts</p>
        <h1 className="text-4xl md:text-5xl font-extrabold tracking-tight text-[#111] mb-6">
          Thoughts & Insights
        </h1>
        <p className="text-gray-500 mb-16 text-lg font-medium">
          Musings on finance, accounting, and building robust business models.
        </p>

        <div className="space-y-12">
          {PORTFOLIO_DATA.blogPosts.map((post) => (
            <motion.article 
              key={post.id} 
              className="group"
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true }}
            >
              <Link to={`/blog/${post.id}`} className="block">
                <time className="text-[10px] font-bold uppercase tracking-widest text-gray-400 block mb-3">
                  {post.date}
                </time>
                <div className="flex items-end justify-between border-b border-gray-200 pb-8 group-hover:border-[#111] transition-colors">
                  <div className="max-w-2xl">
                    <h2 className="text-2xl font-bold text-[#111] mb-3 group-hover:text-blue-600 transition-colors">
                      {post.title}
                    </h2>
                    <p className="text-gray-500 text-base leading-relaxed font-medium">
                      {post.summary}
                    </p>
                  </div>
                  <div className="hidden sm:block pb-2">
                     <ArrowRight className="w-5 h-5 text-gray-300 group-hover:text-[#111] transition-colors" />
                  </div>
                </div>
              </Link>
            </motion.article>
          ))}
        </div>
      </motion.div>
    </div>
  );
}
