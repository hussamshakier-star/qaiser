import { motion } from "motion/react";
import React, { useState } from "react";
import { Mail, Send, CheckCircle } from "lucide-react";
import { PORTFOLIO_DATA } from "../data";

export default function Contact() {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    // Simulate API call
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSubmitted(true);
    }, 1500);
  };

  return (
    <div className="max-w-4xl grid md:grid-cols-2 gap-16 md:gap-12 items-start py-12">
      <motion.div
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.5 }}
      >
        <p className="text-[10px] font-extrabold tracking-[0.2em] text-gray-400 uppercase mb-4">Contact Info</p>
        <h1 className="text-4xl md:text-5xl font-extrabold tracking-tight text-[#111] mb-6">
          Let's Connect
        </h1>
        <p className="text-gray-500 mb-10 text-lg leading-relaxed font-medium">
          I'm always open to new opportunities, collaborations, or discussing financial strategies for your business.
        </p>

        <div className="flex items-center gap-5 text-[#111] bg-gray-50 p-6 rounded-sm border border-gray-100">
          <div className="w-14 h-14 rounded-full border border-gray-200 flex flex-shrink-0 items-center justify-center bg-white shadow-sm">
            <Mail className="w-5 h-5 text-[#111]" />
          </div>
          <div className="overflow-hidden">
            <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1 truncate">Direct Email</p>
            <a href={`mailto:${PORTFOLIO_DATA.contact.email}`} className="text-lg font-bold text-[#111] hover:text-blue-600 transition-colors truncate block">
              {PORTFOLIO_DATA.contact.email}
            </a>
          </div>
        </div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, x: 20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.5, delay: 0.1 }}
      >
        {isSubmitted ? (
          <div className="h-full min-h-[400px] bg-gray-50 border border-gray-100 rounded-sm p-10 flex flex-col items-center justify-center text-center">
            <CheckCircle className="w-16 h-16 text-green-500 mb-6" />
            <h3 className="text-2xl font-bold text-[#111] mb-3">Message Sent</h3>
            <p className="text-gray-500 max-w-sm">Thanks for reaching out! I'll get back to you as soon as possible.</p>
            <button 
              onClick={() => setIsSubmitted(false)}
              className="mt-8 px-6 py-3 bg-white shadow-sm rounded-sm text-xs font-bold text-[#111] border border-gray-200 hover:border-gray-400 transition-all tracking-widest uppercase"
            >
              Send Another
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="bg-gray-50 border border-gray-100 rounded-sm p-8 space-y-6">
            <div>
              <label htmlFor="name" className="block text-[10px] font-bold uppercase tracking-widest text-gray-400 mb-2">Name</label>
              <input 
                type="text" 
                id="name" 
                required
                className="w-full bg-white border border-gray-200 rounded-sm px-4 py-3 text-[#111] font-medium focus:outline-none focus:border-[#111] transition-colors placeholder:text-gray-300 placeholder:font-normal shadow-sm"
                placeholder="John Doe"
              />
            </div>
            <div>
              <label htmlFor="email" className="block text-[10px] font-bold uppercase tracking-widest text-gray-400 mb-2">Email</label>
              <input 
                type="email" 
                id="email" 
                required
                className="w-full bg-white border border-gray-200 rounded-sm px-4 py-3 text-[#111] font-medium focus:outline-none focus:border-[#111] transition-colors placeholder:text-gray-300 placeholder:font-normal shadow-sm"
                placeholder="john@example.com"
              />
            </div>
            <div>
              <label htmlFor="message" className="block text-[10px] font-bold uppercase tracking-widest text-gray-400 mb-2">Message</label>
              <textarea 
                id="message" 
                rows={4}
                required
                className="w-full bg-white border border-gray-200 rounded-sm px-4 py-3 text-[#111] font-medium focus:outline-none focus:border-[#111] transition-colors resize-none placeholder:text-gray-300 placeholder:font-normal shadow-sm"
                placeholder="Hello, let's work together..."
              ></textarea>
            </div>
            <button 
              type="submit" 
              disabled={isSubmitting}
              className="w-full bg-[#111] text-white font-bold tracking-widest uppercase text-xs rounded-sm py-4 px-4 hover:bg-black focus:outline-none focus:ring-2 focus:ring-[#111]/30 transition-all flex items-center justify-center gap-2 disabled:opacity-70 disabled:cursor-not-allowed"
            >
              {isSubmitting ? (
                "Sending..."
              ) : (
                <>
                  Send Message <Send className="w-4 h-4 ml-1" />
                </>
              )}
            </button>
          </form>
        )}
      </motion.div>
    </div>
  );
}
