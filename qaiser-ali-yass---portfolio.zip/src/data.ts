export const PORTFOLIO_DATA = {
  name: "Qaiser Ali Yass",
  role: "Accountant",
  about: "I am a detail-oriented and analytical Accountant with expertise in financial reporting, corporate tax compliance, and auditing. I excel in optimizing financial processes, ensuring regulatory compliance, and delivering actionable insights to drive business growth. Passionate about leveraging numbers to build strategic success.",
  contact: {
    email: "contact@example.com",
    github: "https://github.com",
    linkedin: "https://linkedin.com",
    twitter: "https://twitter.com",
    instagram: "https://instagram.com",
    facebook: "https://facebook.com",
  },
  skills: [
    "Financial Accounting", "Bookkeeping", "Tax Preparation", "Financial Analysis", "Advanced Excel", "QuickBooks", "ERP Systems", "Payroll Management", "Auditing", "Reconciliation"
  ],
  casualWork: [
    {
      title: "Bookkeeping & Chill",
      description: "Keeping your ledgers perfectly balanced so you can focus on running your business (and sleep better at night).",
      icon: "Calculator"
    },
    {
      title: "Tax Magic",
      description: "Navigating the complex maze of tax codes to find every legitimate deduction you deserve. Less stress, more savings.",
      icon: "Sparkles"
    },
    {
      title: "Financial Therapy",
      description: "Turning a chaotic shoebox of receipts into clear, beautiful, and actionable profit & loss statements.",
      icon: "Coffee"
    },
    {
      title: "Audit Shield",
      description: "Organizing your financial records so meticulously that you'll be over-prepared and won't have to panic.",
      icon: "Shield"
    }
  ],
  projects: [
    {
      id: "1",
      title: "Financial Restructuring & Cost Reduction",
      description: "Led a corporate financial restructuring initiative that optimized budgeting processes and reduced operational costs by 15% over a fiscal year.",
      tech: ["Financial Analysis", "Budgeting", " Forecasting"],
      link: "#",
      imageUrl: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?q=80&w=2015&auto=format&fit=crop"
    },
    {
      id: "2",
      title: "Cloud ERP Implementation",
      description: "Managed the migration of legacy financial records to a modern Cloud ERP system, ensuring zero data loss and reducing reporting time by 30%.",
      tech: ["ERP Systems", "Data Migration", "Process Optimization"],
      link: "#",
      imageUrl: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?q=80&w=2070&auto=format&fit=crop"
    },
    {
      id: "3",
      title: "Comprehensive Year-End Audit",
      description: "Coordinated with external auditors to complete a seamless year-end audit for a mid-sized enterprise, reconciling complex accounts and ensuring full regulatory compliance.",
      tech: ["Auditing", "Reconciliation", "Regulatory Compliance"],
      link: "#",
      imageUrl: "https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?q=80&w=2070&auto=format&fit=crop"
    }
  ],
  blogPosts: [
    {
      id: "1",
      title: "The Importance of Cash Flow Management",
      date: "May 1, 2026",
      summary: "Why monitoring your cash flow is critical to the survival and growth of small businesses.",
      content: "Cash is the lifeblood of any business. While profitability is a long-term goal, maintaining positive cash flow is essential for day-to-day operations. In this post, we explore effective strategies for managing accounts receivable, optimizing accounts payable, and forecasting future cash needs to ensure steady business operations and avoid unexpected shortfalls."
    },
    {
      id: "2",
      title: "Navigating Tax Season: Tips for Business Owners",
      date: "April 15, 2026",
      summary: "Essential preparation steps to ensure a smooth and penalty-free tax season.",
      content: "Tax season doesn't have to be overwhelming. By maintaining organized records throughout the year, understanding deductible expenses, and utilizing the right accounting software, business owners can significantly reduce their tax burden and avoid stress. We discuss common pitfalls, the importance of separating personal and business finances, and when to consult a professional."
    },
    {
      id: "3",
      title: "How Automation is Transforming Accounting",
      date: "March 22, 2026",
      summary: "Exploring the shift from manual data entry to automated financial systems.",
      content: "The accounting profession is evolving. Automation tools and AI are increasingly handling repetitive tasks such as invoice processing, expense categorization, and basic reconciliations. This shift allows accountants to focus more on strategic financial advisory, data analysis, and helping businesses make informed, forward-looking decisions. Embracing these technologies is key to staying competitive."
    }
  ]
};
