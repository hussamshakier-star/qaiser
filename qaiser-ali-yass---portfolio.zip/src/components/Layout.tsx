import { useState } from "react";
import { Outlet, Link } from "react-router-dom";
import { PORTFOLIO_DATA } from "../data";
import { Menu, X, Twitter, Linkedin, Github, Mail, Phone, Instagram, Facebook } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

export default function Layout() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <div className="min-h-screen flex flex-col font-sans bg-white text-[#111]">
      <div className="max-w-[1400px] w-full mx-auto px-6 lg:px-16 flex-1 flex flex-col">
        {/* Header */}
        <header className="py-10 flex items-center justify-between border-transparent z-50 relative bg-white/80 border-b border-white backdrop-blur-sm">
          <motion.div initial="rest" whileHover="hover" animate="rest">
            <Link to="/" className="flex items-center gap-4 group">
              <div className="w-14 h-14 rounded-full border-2 border-[#111] flex items-center justify-center overflow-hidden bg-gray-100 shrink-0">
                <img src="qa.png" alt="Qaiser Ali Yass" className="w-full h-full object-cover" />
              </div>
              <div className="flex flex-col">
                <div className="font-bold text-xs tracking-widest leading-none mb-[2px] flex uppercase items-center">
                  <span className="flex">
                    <span>Q</span>
                    <motion.span
                      variants={{ rest: { width: 0, opacity: 0 }, hover: { width: "auto", opacity: 1 } }}
                      className="overflow-hidden whitespace-nowrap"
                      transition={{ duration: 0.3, ease: "easeOut" }}
                    >
                      AISER&nbsp;
                    </motion.span>
                  </span>
                  <span className="flex">
                    <span>A</span>
                    <motion.span
                      variants={{ rest: { width: 0, opacity: 0 }, hover: { width: "auto", opacity: 1 } }}
                      className="overflow-hidden whitespace-nowrap"
                      transition={{ duration: 0.3, ease: "easeOut" }}
                    >
                      LI&nbsp;
                    </motion.span>
                  </span>
                  <span className="flex">
                    <span>Y</span>
                    <motion.span
                      variants={{ rest: { width: 0, opacity: 0 }, hover: { width: "auto", opacity: 1 } }}
                      className="overflow-hidden whitespace-nowrap"
                      transition={{ duration: 0.3, ease: "easeOut" }}
                    >
                      ASS
                    </motion.span>
                  </span>
                </div>
                <span className="text-[9px] uppercase tracking-[0.2em] text-gray-500 font-bold">Accountant</span>
              </div>
            </Link>
          </motion.div>
          <nav>
            <button 
              onClick={() => setIsMenuOpen(true)}
              className="flex items-center gap-2 text-xs font-bold tracking-[0.1em] uppercase hover:text-gray-500 transition-colors"
            >
              Menu <Menu className="w-5 h-5 ml-1" />
            </button>
          </nav>
        </header>

        {/* Main Content */}
        <main className="flex-1 w-full">
          <Outlet />
        </main>
      </div>

      {/* Footer */}
      <footer className="bg-[#111] text-white py-20 mt-24">
        <div className="max-w-[1400px] w-full mx-auto px-6 lg:px-16">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-12 md:gap-8 mb-16">
            <div className="col-span-1 md:col-span-2">
              <h2 className="text-2xl font-bold mb-4">{PORTFOLIO_DATA.name}</h2>
              <p className="text-gray-400 text-sm max-w-sm leading-relaxed">
                Expert in financial and corporate reporting. Helping businesses thrive with meticulous accounting strategies.
              </p>
            </div>
            
            <div>
              <h3 className="text-[10px] font-extrabold tracking-[0.2em] text-gray-500 uppercase mb-6">Navigation</h3>
              <ul className="space-y-3 text-sm font-medium">
                <li><Link to="/" className="text-gray-300 hover:text-white transition-colors">Home</Link></li>
                <li><a href="/#projects" className="text-gray-300 hover:text-white transition-colors">Projects</a></li>
                <li><Link to="/blog" className="text-gray-300 hover:text-white transition-colors">Blog</Link></li>
                <li><Link to="/contact" className="text-gray-300 hover:text-white transition-colors">Contact</Link></li>
              </ul>
            </div>

            <div>
              <h3 className="text-[10px] font-extrabold tracking-[0.2em] text-gray-500 uppercase mb-6">Contact</h3>
              <ul className="space-y-4 text-sm font-medium">
                <li>
                  <a href={`mailto:${PORTFOLIO_DATA.contact.email}`} className="flex items-center gap-3 text-gray-300 hover:text-white transition-colors">
                    <Mail className="w-4 h-4 text-gray-500" />
                    {PORTFOLIO_DATA.contact.email}
                  </a>
                </li>
                <li>
                  <a href="tel:+1234567890" className="flex items-center gap-3 text-gray-300 hover:text-white transition-colors">
                    <Phone className="w-4 h-4 text-gray-500" />
                    +1 234 567 890
                  </a>
                </li>
              </ul>
              
              <div className="flex flex-wrap items-center gap-4 mt-8">
                <a href={PORTFOLIO_DATA.contact.twitter} className="w-10 h-10 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-white hover:bg-white/20 transition-all hover:-translate-y-1">
                  <Twitter className="w-4 h-4" />
                </a>
                <a href={PORTFOLIO_DATA.contact.linkedin} className="w-10 h-10 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-white hover:bg-white/20 transition-all hover:-translate-y-1">
                  <Linkedin className="w-4 h-4" />
                </a>
                <a href={PORTFOLIO_DATA.contact.github} className="w-10 h-10 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-white hover:bg-white/20 transition-all hover:-translate-y-1">
                  <Github className="w-4 h-4" />
                </a>
                <a href={PORTFOLIO_DATA.contact.instagram} className="w-10 h-10 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-white hover:bg-white/20 transition-all hover:-translate-y-1">
                  <Instagram className="w-4 h-4" />
                </a>
                <a href={PORTFOLIO_DATA.contact.facebook} className="w-10 h-10 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-white hover:bg-white/20 transition-all hover:-translate-y-1">
                  <Facebook className="w-4 h-4" />
                </a>
              </div>
            </div>
          </div>
          
          <div className="pt-8 border-t border-white/10 flex flex-col md:flex-row items-center justify-between gap-4 text-[10px] font-bold tracking-widest uppercase text-gray-500">
            <p>&copy; {new Date().getFullYear()} {PORTFOLIO_DATA.name}. All rights reserved.</p>
            <p>Designed with Intent</p>
          </div>
        </div>
      </footer>

      {/* Menu Overlay */}
      <AnimatePresence>
        {isMenuOpen && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="fixed inset-0 z-[100] bg-white flex flex-col"
          >
            <div className="max-w-[1400px] w-full mx-auto px-6 lg:px-16 py-10 flex items-center justify-between border-transparent">
              <div className="w-14 h-14 rounded-full border-2 border-[#111] flex items-center justify-center font-bold text-lg overflow-hidden shrink-0">
                <img src="qa.png" className="w-full h-full object-cover" />
              </div>
              <button 
                onClick={() => setIsMenuOpen(false)}
                className="flex items-center gap-2 text-xs font-bold tracking-[0.1em] uppercase hover:text-gray-500 transition-colors"
              >
                Close <X className="w-5 h-5 ml-1" />
              </button>
            </div>
            
            <div className="flex-1 flex flex-col text-center justify-center space-y-8">
              <motion.div initial={{ y: 20, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: 20, opacity: 0 }} transition={{ delay: 0.1 }}>
                <Link to="/" onClick={() => setIsMenuOpen(false)} className="text-5xl md:text-7xl font-extrabold tracking-tight text-[#111] hover:text-gray-500 transition-colors">Home</Link>
              </motion.div>
              <motion.div initial={{ y: 20, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: 20, opacity: 0 }} transition={{ delay: 0.2 }}>
                <a href="/#projects" onClick={() => setIsMenuOpen(false)} className="text-5xl md:text-7xl font-extrabold tracking-tight text-[#111] hover:text-gray-500 transition-colors">Projects</a>
              </motion.div>
              <motion.div initial={{ y: 20, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: 20, opacity: 0 }} transition={{ delay: 0.3 }}>
                <Link to="/blog" onClick={() => setIsMenuOpen(false)} className="text-5xl md:text-7xl font-extrabold tracking-tight text-[#111] hover:text-gray-500 transition-colors">Blog</Link>
              </motion.div>
              <motion.div initial={{ y: 20, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: 20, opacity: 0 }} transition={{ delay: 0.4 }}>
                <Link to="/contact" onClick={() => setIsMenuOpen(false)} className="text-5xl md:text-7xl font-extrabold tracking-tight text-[#111] hover:text-gray-500 transition-colors">Contact</Link>
              </motion.div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
